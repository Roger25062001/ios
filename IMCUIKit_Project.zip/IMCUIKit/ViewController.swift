import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var txtNombre: UITextField!
    @IBOutlet weak var txtPeso: UITextField!
    @IBOutlet weak var txtAltura: UITextField!
    @IBOutlet weak var segSexo: UISegmentedControl!

    @IBAction func calcularIMC(_ sender: UIButton) {
        guard let nombre = txtNombre.text, !nombre.isEmpty,
              let peso = Double(txtPeso.text ?? ""), peso > 0,
              let altura = Double(txtAltura.text ?? ""), altura > 0 else {
            return
        }
        let sexo = segSexo.selectedSegmentIndex == 0 ? "Femenino" : "Masculino"
        let imc = peso / (altura * altura)
        let vc = storyboard!.instantiateViewController(withIdentifier: "DetailViewController") as! DetailViewController
        vc.nombre = nombre; vc.peso = peso; vc.altura = altura; vc.sexo = sexo; vc.imc = imc
        navigationController?.pushViewController(vc, animated: true)
    }
}