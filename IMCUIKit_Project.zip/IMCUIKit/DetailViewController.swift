import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var lblNombre: UILabel!
    @IBOutlet weak var lblPeso: UILabel!
    @IBOutlet weak var lblAltura: UILabel!
    @IBOutlet weak var lblSexo: UILabel!
    @IBOutlet weak var lblIMC: UILabel!
    @IBOutlet weak var lblCategoria: UILabel!

    var nombre: String!; var peso: Double!; var altura: Double!; var sexo: String!; var imc: Double!

    override func viewDidLoad() {
        super.viewDidLoad()
        lblNombre.text = nombre
        lblPeso.text = "\(peso!) kg"
        lblAltura.text = "\(altura!) m"
        lblSexo.text = sexo
        lblIMC.text = String(format: "%.1f", imc)
        if imc < 18.5 { lblCategoria.text = "Bajo peso"; lblCategoria.textColor = .orange }
        else if imc < 25 { lblCategoria.text = "Peso normal"; lblCategoria.textColor = .green }
        else if imc < 30 { lblCategoria.text = "Sobrepeso"; lblCategoria.textColor = .yellow }
        else { lblCategoria.text = "Obesidad"; lblCategoria.textColor = .red }
    }
}